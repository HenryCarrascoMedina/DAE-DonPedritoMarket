// src/App.jsx
import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';

const initialProducts = [
  { id: 1, name: 'Arroz', price: 20, imageUrl: 'https://images.unsplash.com/photo-1604908177524-c688b7e29df4?auto=format&fit=crop&w=600&q=60' },
  { id: 2, name: 'Aceite', price: 35, imageUrl: 'https://images.unsplash.com/photo-1627308595229-7830a5c91f9f?auto=format&fit=crop&w=600&q=60' },
  { id: 3, name: 'Azúcar', price: 25, imageUrl: 'https://images.unsplash.com/photo-1626129245163-4dce783e3df4?auto=format&fit=crop&w=600&q=60' },
  { id: 4, name: 'Sal', price: 10, imageUrl: 'https://images.unsplash.com/photo-1612182069183-d0d9a0bc0b0b?auto=format&fit=crop&w=600&q=60' },
  { id: 5, name: 'Fideos', price: 18, imageUrl: 'https://images.unsplash.com/photo-1588165941081-c086f9c2ed4c?auto=format&fit=crop&w=600&q=60' },
  { id: 6, name: 'Harina', price: 22, imageUrl: 'https://images.unsplash.com/photo-1603724513798-62b8803948ec?auto=format&fit=crop&w=600&q=60' },
  { id: 7, name: 'Leche', price: 30, imageUrl: 'https://images.unsplash.com/photo-1587049352846-4e07e5ebdf3c?auto=format&fit=crop&w=600&q=60' },
  { id: 8, name: 'Café', price: 50, imageUrl: 'https://images.unsplash.com/photo-1510626176961-4bfb7e21b1f1?auto=format&fit=crop&w=600&q=60' },
  { id: 9, name: 'Galletas', price: 15, imageUrl: 'https://images.unsplash.com/photo-1617134192901-f27b5c6c7bfb?auto=format&fit=crop&w=600&q=60' },
  { id: 10, name: 'Chocolate', price: 45, imageUrl: 'https://images.unsplash.com/photo-1614707267530-2de54892535f?auto=format&fit=crop&w=600&q=60' }
];

function App() {
  const [cart, setCart] = useState([]);
  const [email, setEmail] = useState(localStorage.getItem('userEmail') || '');

  const addToCart = (product) => setCart([...cart, product]);
  const total = cart.reduce((sum, item) => sum + item.price, 0);
  const handleLogin = () => email && localStorage.setItem('userEmail', email);
  const handleLogout = () => {
    localStorage.removeItem('userEmail');
    setEmail('');
    setCart([]);
  };

  return (
    <div className="bg-light min-vh-100 d-flex flex-column">
      <nav className="navbar navbar-expand-lg navbar-dark bg-success">
        <div className="container-fluid">
          <span className="navbar-brand">Don Pedrito Market 🛒</span>
          <div className="d-flex">
            {email ? (
              <>
                <span className="text-white me-3">Hola, {email}</span>
                <button className="btn btn-outline-light btn-sm" onClick={handleLogout}>Cerrar sesión</button>
              </>
            ) : (
              <div className="d-flex">
                <input
                  type="email"
                  className="form-control form-control-sm me-2"
                  placeholder="Tu correo"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                <button className="btn btn-outline-light btn-sm" onClick={handleLogin}>Iniciar sesión</button>
              </div>
            )}
          </div>
        </div>
      </nav>

      <div className="container-fluid py-4 flex-grow-1">
        <h2 className="mb-4 text-center text-success">Productos</h2>
        <div className="row">
          {initialProducts.map((product) => (
            <div className="col-6 col-sm-4 col-md-3 mb-3" key={product.id}>
              <div className="card h-100 shadow-sm">
                <img src={product.imageUrl} className="card-img-top" alt={product.name} style={{ height: '120px', objectFit: 'cover' }} />
                <div className="card-body d-flex flex-column">
                  <h6 className="card-title mb-1">{product.name}</h6>
                  <p className="card-text small">Precio: ${product.price}</p>
                  <button className="btn btn-sm btn-primary mt-auto" onClick={() => addToCart(product)}>Agregar</button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div id="carouselExample" className="carousel slide my-5" data-bs-ride="carousel">
          <div className="carousel-inner">
            <div className="carousel-item active">
              <img src="" className="d-block w-100" alt="banner1" />
            </div>
            <div className="carousel-item">
              <img src="https://source.unsplash.com/random/1200x300?groceries" className="d-block w-100" alt="banner2" />
            </div>
            <div className="carousel-item">
              <img src="https://source.unsplash.com/random/1200x300?store" className="d-block w-100" alt="banner3" />
            </div>
          </div>
          <button className="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
            <span className="carousel-control-prev-icon"></span>
          </button>
          <button className="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
            <span className="carousel-control-next-icon"></span>
          </button>
        </div>

        <h3 className="mt-5 text-center"><i className="bi bi-cart-check me-2"></i>Carrito de Compras</h3>
        {cart.length === 0 ? (
          <p className="text-muted text-center">Tu carrito está vacío</p>
        ) : (
          <ul className="list-group mb-3">
            {cart.map((item, index) => (
              <li key={index} className="list-group-item d-flex justify-content-between">
                {item.name} <span>${item.price}</span>
              </li>
            ))}
            <li className="list-group-item d-flex justify-content-between fw-bold">
              Total <span>${total}</span>
            </li>
          </ul>
        )}
      </div>

      <footer className="bg-dark text-white text-center py-4 mt-auto">
        <p className="mb-1">Don Pedrito Market S.A.</p>
        <p className="mb-1">Dirección: Calle Principal 123, Lima, Perú</p>
        <p className="mb-1">Teléfono: +51 987 654 321</p>
        <p className="mb-0">Email: contacto@donpedritomarket.com</p>
      </footer>
    </div>
  );
}

export default App;
